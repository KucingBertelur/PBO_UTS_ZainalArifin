package Soal;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author a
 */
public class soal_2 { 
    public static void main(String[] args){
        String nama = "Zainal Arifin";
        String Program_Studi = "Ilmu Komputer";
        String nama_kampus = "Stkom Sapta Computer";
        
        System.out.println("Nama Mahasiswa = "+nama);
        System.out.println("Program Studi  = "+Program_Studi);       
        System.out.println("Nama Kampus    = "+nama_kampus);   
    }   
}