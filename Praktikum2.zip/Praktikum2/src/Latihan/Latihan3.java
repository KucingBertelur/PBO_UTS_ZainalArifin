package Latihan;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author a
 */
public class Latihan3 {
    public static void main(String[] args){
        String matakuliah = "Pemrograman Berbasis Objek";
        String singkatan = "PBO";
        String sks = "3";
        String pengajar= "Zainal Arifin";
        
        System.out.println("Matakuliah  = "+matakuliah);
        System.out.println("Singkatan   = "+singkatan);
        System.out.println("SKS         = "+sks);
        System.out.println("Pengajar    = "+pengajar);   
    }
}