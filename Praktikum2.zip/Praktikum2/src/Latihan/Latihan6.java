package Latihan;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.util.Scanner;

/**
 *
 * @author a
 */
public class Latihan6 {
     public static void main(String[] args){
        int angka;
        Scanner inputan = new Scanner(System.in).useDelimiter("\n");
        System.out.print("Masukkan Angka : ");
        angka = inputan.nextInt();
        System.out.print("Angka yang diinputkan adalah "+angka);   
     }
}