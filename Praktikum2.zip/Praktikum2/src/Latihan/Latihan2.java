package Latihan;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author a
 */
public class Latihan2 {
    public static void main(String[] args){
        //ini adalah catatan
        System.out.println("Ini Cuman Print");
        System.out.println("Ini Cuman Println");
        
        System.out.println(" ");   //" "Untuk Memberi Jarak Spasi dengan yang diatas
        
        //angka kesamping
        System.out.println("1,2,3");
        
        //angka kebawah
        System.out.println("");
        System.out.println("1");
        System.out.println("2");
        System.out.println("3");
    }   
}