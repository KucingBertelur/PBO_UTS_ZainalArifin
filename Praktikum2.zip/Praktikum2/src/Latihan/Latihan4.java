package Latihan;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author a
 */
public class Latihan4 {
    public static void main(String[] args){
        String sistem_Operasi = "Windows 10",versi = "64 bit", pemilik="Zainal Arifin";
        
        System.out.println("Sistem Operasi = "+sistem_Operasi);
        System.out.println("Versi          = "+versi);
        System.out.println("Pemilik        = "+pemilik);
    }
}